
public class Driver {
	public static void main(String [] args) {
		Mymath m = new Mymath();
		m.Add(5, 3);
		m.Divide(8, 4);
		m.Subtract(10, 5);
		m.Multiply(12, 4);
	}
	
}